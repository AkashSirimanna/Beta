<?php
header('location: wordpress');
?>